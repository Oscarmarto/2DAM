import java.util.Scanner;

public class ej2 {
    public static void main(String[] args) {

        System.out.print("Com et dius? ");
        Scanner teclat = new Scanner(System.in);
        String nom = teclat.nextLine();
        System.out.println("Hola "+nom);
    }
}
