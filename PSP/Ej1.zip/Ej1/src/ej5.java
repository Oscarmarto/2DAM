import java.util.Scanner;

public class ej5 {
    public static void main(String[] args) {
        boolean igual = false;

        do {
            System.out.println("Comparacion de numeros");
            Scanner num = new Scanner(System.in);
            System.out.print("Numero 1 :");
            int num1 = num.nextInt();
            System.out.print("Numero 2 :");
            int num2 = num.nextInt();
            if(num1 == num2) {
                System.out.println("Els numeros son iguals");
                igual = true;
            }
        }while(igual == false);

    }

}
