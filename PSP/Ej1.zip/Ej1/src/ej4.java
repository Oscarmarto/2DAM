import java.util.Scanner;

public class ej4 {
    public static void main(String[] args) {

        System.out.println("Comparacion de numeros");
        Scanner num = new Scanner(System.in);
        System.out.print("Numero 1 :");
        int num1 = num.nextInt();
        System.out.print("Numero 2 :");
        int num2 = num.nextInt();

        if(num1 == num2) {
            System.out.println("Els numeros son iguals");
        }else {
            System.out.println("El mes alt es "+Math.max(num1, num2)+" y el mes xicotet "+Math.min(num1, num2));
        }

    }
}
