public class ej31 {

    public void sayHello() {
        System.out.println("Hola Món");
    }

    public static void main(String[] args) {
        ej31 app = new ej31();
        app.sayHello();
    }
}


