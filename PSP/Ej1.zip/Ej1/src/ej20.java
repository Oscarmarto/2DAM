public class ej20 {
    public static void main(String[] args) {
        for (int i = 0; i < 255; i++) {
            char c = (char) i;
            System.out.println(i + "  ||  " + c);
        }
    }
}
