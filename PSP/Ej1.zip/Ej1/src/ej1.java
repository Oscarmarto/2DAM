public class ej1 {

        public static void main(String[] args) {

            int num1 = 3;
            int num2 = 5;
            int suma = num1 + num2;

            System.out.println("La suma entre "+num1+" y "+num2+" dona "+suma);
        }

    }

