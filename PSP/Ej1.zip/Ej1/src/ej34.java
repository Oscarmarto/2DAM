public class ej34 {
    public static void main(String[] args) {
        long fact = 1;
        for (int i = 1; i <= 15; i++) fact *= i;
        System.out.println("El factorial de 15 és: " + fact);
    }
}
