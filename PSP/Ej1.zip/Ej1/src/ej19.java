import java.util.Scanner;

public class ej19 {
    public static void main(String[] args) {
        for (int i = 0; i < 128; i++) {
            char c = (char) i;
            System.out.println(i + "  ||  " + c);
        }
    }
}

